const rules = document.getElementById('rules');
const closed = document.getElementById('close');
let popUp = document.querySelector('.rules_popup');
const playerChoosePaper = document.querySelector('.paper')
const playerChooseRock = document.querySelector('.rock')
const playerChooseScissors = document.querySelector('.scissors')
const scoreId = document.createElement('span')
scoreId.id = 'score'

const mainLandingPage = document.querySelector('.choice-container')

const playAgain = document.querySelector('#play_again')

// const winOrLose = document.querySelector('.win-lose');
// const draw = document.querySelector('.finalresult');

let winOrLose = document.createElement('h1')

const forComputerChoice = ['paper','rock','scissors']
let playerChoice;

const PAPER = 'paper'
const ROCK = 'rock'
const SCISSORS = 'scissors'
let houseChoice;

let score = 0;

// ############ player choice show on screen #########

function playerPicked(playerChoice) {
    let choosedResult = document.querySelector('.choosed_result')

    let choice = playerChoice;
    
    choosedResult.className = `choosed_result yourchoice choice_${choice}`
    choosedResult.innerHTML = `<div class="shadow"> </div> <img src="./images/icon-${choice}.svg" alt="${choice}">`;
    
}

// ############ computer choice show on screen #########

function housePicked(housechoice) {
    let choosedResult = document.querySelector('#house-choice')
    console.log(choosedResult);

    houseChoice = housechoice;   
    
    choosedResult.className = `choosed_result computerchoice choice_${houseChoice} `
    choosedResult.innerHTML = `<div class="shadow house-shadow"> </div><img src="./images/icon-${houseChoice}.svg" alt="${houseChoice}">`;
    

}

// ############ computer make choice ##########

function computerChoice() {
    // let houseChoice;
    let random = Math.floor(Math.random()*forComputerChoice.length);
    houseChoice = forComputerChoice[random];
    housePicked(houseChoice);
}


// ############# to return final result ############

function result(plaeyArgument,houseArgument) {
    const selectResult = document.querySelector('.result');
    const win_lose = document.querySelector('.win-lose')
    let choosedResult = document.querySelector('#house-choice')
    const showShadow = document.querySelector('.shadow')
    const showShadowHouse = document.querySelector('.house-shadow')
    const scoreSpan = document.querySelector('.score')

    
    console.log(showShadow)
    console.log(showShadowHouse)

    winOrLose.innerHTML = ` YOU <span class ="win-lose"></span>`

    selectResult.prepend(winOrLose);

    

    if (plaeyArgument === houseArgument) {
        winOrLose.innerHTML = ` DRAW <span class ="win-lose"></span>`
    } else if (plaeyArgument === PAPER && houseArgument === ROCK || plaeyArgument === SCISSORS && houseArgument === PAPER || plaeyArgument === ROCK && houseArgument === SCISSORS) {
        winOrLose.innerHTML = ` YOU <span class ="win-lose">win</span>`
        const win_lose = document.querySelector('.win-lose')
        win_lose.style.color = 'green'
        showShadow.className = `shadow shadow_${plaeyArgument} `
        scoreSpan.append(scoreId)
        scoreId.innerHTML = ++score;

        // console.log('win')
    } else {
        winOrLose.innerHTML = ` YOU <span class ="win-lose">lose</span>`
        const win_lose = document.querySelector('.win-lose')
        win_lose.style.color = 'red'
        showShadowHouse.className = `shadow shadow_${houseArgument} `
        console.log('lose')
        
    }




}


// ############## toggle rules page ##########

function popup() {
    popUp.classList.toggle('visible');
    console.log(popUp);
}

// ############## toggle main page ##########

function landingPage() {
    mainLandingPage.classList.toggle('visible')
}

// ############## toggle rusult page ##########

function resultPage(){
    const result = document.getElementById('result')

    result.classList.toggle('visible');
}

// ########### playe again function #############

function playagain(){
    resultPage();
    landingPage();
}

// ######## player make choice and call funcitons  ##############

function paper() {
    playerChoice = PAPER;
    landingPage();
    resultPage();
    playerPicked(playerChoice)
    computerChoice()
    result(playerChoice,houseChoice);
}
function rock() {
    playerChoice = ROCK;
    landingPage();
    resultPage();
    playerPicked(playerChoice)
    computerChoice()
    result(playerChoice,houseChoice);
}
function scissors() {
    playerChoice = SCISSORS;
    landingPage();
    resultPage();
    playerPicked(playerChoice)
    computerChoice()
    result(playerChoice,houseChoice);
}




// ############ event handler ############

closed.addEventListener('click',popup);
rules.addEventListener('click',popup);
playerChoosePaper.addEventListener('click',paper)
playerChooseRock.addEventListener('click',rock)
playerChooseScissors.addEventListener('click',scissors)
playAgain.addEventListener('click',playagain)